(function () {
  var A = {
      7703: function (A, e, n) {
        "use strict";
        var t = n(9963),
          a = n(6252);
        function c(A, e) {
          const n = (0, a.up)("router-view");
          return (0, a.wg)(), (0, a.j4)(n);
        }
        var o = n(3744);
        const i = {},
          r = (0, o.Z)(i, [["render", c]]);
        var s = r,
          l = n(2201),
          d = n(3577),
          p = n.p + "img/images/re.gif",
          h = n.p + "img/images/rewards.png",
          m = n.p + "img/images/checkin.png",
          g = n.p + "img/images/homebanner.png",
          fpar = n.p + "img/images/fparity.png",
          rou = n.p + "img/images/wheelocity.png",
          par = n.p + "img/images/parity.png",
          mine = n.p + "img/images/minesweeper.png",
          sapr = n.p + "img/images/sapre.png",
          avi = n.p + "img/images/jetx.png",
          pic = n.p + "img/images/plinko.png",          
          dic = n.p + "img/images/dice.png",
          anbi = n.p + "img/images/andarbahar.png",
          plI = n.p + "img/images/playerImg.png",
          btI = n.p + "img/images/bettingImg.png",
          onI = n.p + "img/images/onlineImg.png",
          appI = n.p + "img/home/apps.png",
          teleI = n.p + "img/home/channel.png",
          helpI = n.p + "img/home/help.png",
          checkI = n.p + "img/home/checkin.png",
          shareI = n.p + "img/home/invite.png",
          nbon = n.p + "img/images/bontp.png",
          I = n.p + "img/images/homeb.png",
          D = n.p + "img/images/bonusBan.png",
          V = n.p + "img/images/channelbanner.png",
          ch = n.p + "img/home/tc.png",
          he = n.p + "img/home/help.png",
          ci = n.p + "img/home/checkin.png",
          iv = n.p + "img/home/invite.png",
          bonban = n.p + "img/images/bonusBan.png",
          ap = n.p + "img/home/apps.png";
        const C = {
            class: "container-fluid",
          },
          R = {
            class: "row mcas",
          },
          E = {
            class: "col-md-6 col-lg-4 main",
            style: {
              background: "rgb(39, 44, 50)",
            },
          },
          Z = {
            class: "row",
            id: "warea",
          },
          L = {
            class: "col-12 pl-1 pr-1",
          },
          Q = {
            class: "row new-top",
          },
          l1 = {
            class: "col-12 new-top-l1",
          },
          l1sec = {
            class: "col-12 l1sec",
          },
          l1isec = {
            class: "l1isec",
          },
          l1icn = {
            class:"l1icn",
          },
          l2 = {
            class: "col-6 new-top-l2",
          },
          l2seccir = {
            class: "l2seccir",
          },
          l2secid = {
            class: "l2secid",
          },
          l2idsec = {
            class: "row col-12 l2idsec",
          },
          l2secbal = {
            class: "col-12 l2secbal",
          },
          M = {
            class: "col-6 xtl",
            style: {
              color: "#fff",
            },
          },
          P = (0, a._)(
            "div",
            {
              class: "mt-1 mb-2 tf-16",
            },
            "Balance",
            -1
          ),
          G = {
            class: "mt-1 mb-2 tfcdb tfw-6 tffss tf-18 tfwr ddavc",
            style: {
              color: "#fff",
            },
          },
          x = {
            class: "tf-16 tfw-6",
            id: "",
          },
          N = {
            class: "pr-2",
          },
          K = {
            class: "mt-1 tf-16 tfcdg",
            style: {
              color: "#fff",
            },
          },
          j = {
            id: "u_id",
          },
          Y = (0, a._)(
            "div",
            {
              class: "col-6 jcrdg",
              style: {
                "padding-right": "4px",
                height: "100%",
                "align-content": "space-around",
              },
            },
            [
              (0, a._)(
                "div",
                {
                  class: "rc-wal",
                  onclick: "window.location.href='#/recharge'",
                },
                [
                  (0, a._)("span", {
                    class: "fa-solid fa-circle-dollar-to-slot pr-2",
                  }),
                  (0, a._)(
                    "div",
                    {
                      id: "btn_tx",
                    },
                    "ADD CASH"
                  ),
                ]
              ),
              (0, a._)(
                "div",
                {
                  class: "wd-bal",
                  onclick: "window.location.href='#/withdrawal'",
                  style: {
                    color: "black",
                  },
                },
                [
                  (0, a._)("span", {
                    class: "fa-solid fa-landmark pr-2",
                  }),
                  (0, a._)(
                    "div",
                    {
                      id: "btn_tx",
                    },
                    "WITHDRAW"
                  ),
                ]
              ),
            ],
            -1
          ),
          F = (0, a._)(
            "div",
            {
              class: "col-12",
            },
            [
              (0, a._)(
                "div",
                {
                  class: "row tf-12 tfcdb tfw-7 1wtj0ep pbt-16",
                },
                [
                  (0, a._)(
                    "div",
                    {
                      class: "tpnvbar",
                    },
                    [
                      //          (0, a._)(
                      //            "div",
                      //            {
                      //              class: "tpnvi",
                      //              onclick: "window.location.href='/fivewin.apk'",
                      //            },
                      //            [
                      //              (0, a._)("img", {
                      //                src: appI,
                      //                id: "tpnvimg",
                      //              }),
                      //              (0, a._)(
                      //                "p",
                      //                {
                      //                  id: "tpnvi_p",
                      //                },
                      //                "Download"
                      //              ),
                      //            ]
                      //          ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-12 pr-1 pl-1",
                      onclick: "window.location.href='https://t.me/lukky7club'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: V,
                          }),
                        ]
                      ),
                    ]
                  ),
                  // (0, a._)(
                  //   "div",
                  //   {
                  //     class: "banner",
                  //     id: "scroll-container",
                  //   },
                  //   [
                  //     (0, a._)(
                  //       "div",
                  //       {
                  //         id: "scroll-text",
                  //       },
                  //       "Refer and Earn Money Daily Unlimited No.1 Platform Instant Withdraw www.fastwin.life"
                  //     ),
                  //     (0, a._)(
                  //       "div",
                  //       {
                  //         class: "scroll-element pr-1",
                  //       },
                  //       [
                  //         (0, a._)("span", {
                  //           class: "fa-solid fa-volume-high",
                  //         }),
                  //       ]
                  //     ),
                  //     (0, a._)(
                  //       "div",
                  //       {
                  //         class: "scroll-element2",
                  //       },
                  //       [
                  //         (0, a._)("span", {
                  //           class: "fa-solid fa-fire-flame-curved fa-rotate-30",
                  //           id: "fireicon",
                  //         }),
                  //         (0, a._)(
                  //           "p",
                  //           {
                  //             class: "scrolltxt",
                  //           },
                  //           "Latest Announcement"
                  //         ),
                  //       ]
                  //     ),
                  //   ]
                  // ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/fastparity'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: fpar,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/sapre'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: sapr,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/parity'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: par,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/dice'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: dic,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/andharbhar'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: anbi,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/wheelocity'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: rou,
                          }),
                        ]
                      ),
                    ]
                  ),

                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/minesweeper'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: mine,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/jet'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: avi,
                          }),
                        ]
                      ),
                    ]
                  ),
                  (0, a._)(
                    "div",
                    {
                      class: "col-4 pr-1 pl-1",
                      onclick: "window.location.href='#/wheel'",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "icard",
                        },
                        [
                          (0, a._)("img", {
                            src: pic,
                          }),
                        ]
                      ),
                    ]
                  ),                  
        //          (0, a._)(
        //            "div",
        //            {
        //              class: "col-12 pr-1 pl-1",
        //              onclick: "window.location.href='https://t.me/lukky7club'",
        //            },
        //            [
        //              (0, a._)(
        //                "div",
        //                {
        //                  class: "icard",
        //                },
        //                [
        //                  (0, a._)("img", {
        //                    src: I,
        //                  }),
        //                ]
        //              ),
        //            ]
        //          ),
                ]
              ),
            ],
            -1
          ),
          websec = {
            class: "websec",
          },
          websecbanT = {
            id: "bannerText",
          },
          websecHtext = {
            id: "websecHead",
          },
          websecBanD = {
            class: "banner_div",
          },
          webscDtbx = {
            class: "date_box",
          },
          webscDtbxP = {
            class: "time-section",
          },
          dtbxD = {
            id: "days",
          },
          dtbxH = {
            id: "hours",
          },
          dtbxM = {
            id: "minutes",
          },
          dtbxS = {
            id: "seconds",
          },
          dtbxL = {
            id: "label",
          },
          wbdat = {
            class: "wbdat",
          },
          wbdati = {
            class: "wbdati",
          },
          wbdatp1s = {
            class: "wbdatp1s",
          },
          wbdatp1 = {
            class: "wbdatp1",
          },
          wbdatp2 = {
            class: "wbdatp2",
          },
          T = (0, a._)(
            "div",
            {
              class: "row",
              id: "odrea",
            },
            null,
            -1
          ),
          W = (0, a._)(
            "div",
            {
              class: "row",
              id: "footer",
            },
            [
              (0, a._)(
                "div",
                {
                  class: "col-12 nav-bar adsob",
                  id: "adsob",
                },
                [
                  (0, a._)(
                    "div",
                    {
                      class: "row",
                    },
                    [
                      (0, a._)(
                        "div",
                        {
                          class: "col-13 pa-0",
                        },
                        [
                          (0, a._)(
                            "div",
                            {
                              class: "navItem sel",
                              id: "moxht2b4u",
                              onclick: "window.location.href='#/'",
                            },
                            [
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                [
                                  (0, a._)("span", {
                                    class: "icon home sel",
                                    id: "home",
                                  }),
                                ]
                              ),
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                "Home"
                              ),
                            ]
                          ),
                        ]
                      ),
                      (0, a._)(
                        "div",
                        {
                          class: "col-13 pa-0",
                        },
                        [
                          (0, a._)(
                            "div",
                            {
                              class: "navItem",
                              id: "sfrm6bvy",
                              onclick: "window.location.href='#/recharge'",
                            },

                            [
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                [
                                  (0, a._)("span", {
                                    class: "icon rech",
                                    id: "recharge",
                                  }),
                                ]
                              ),
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                "Recharge"
                              ),
                            ]
                          ),
                        ]
                      ),
                      (0, a._)(
                        "div",
                        {
                          class: "col-13 pa-0",
                        },
                        [
                          (0, a._)(
                            "div",
                            {
                              class: "navItem",
                              id: "raeiyf2m0",
                              onclick: "window.location.href='#/promotion'",
                            },
                            [
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                [
                                  (0, a._)("span", {
                                    class: "icon group",
                                    id: "group",
                                  }),
                                ]
                              ),
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                "Promotion"
                              ),
                            ]
                          ),
                        ]
                      ),
                      (0, a._)(
                        "div",
                        {
                          class: "col-13 pa-0",
                        },
                        [
                          (0, a._)(
                            "div",
                            {
                              class: "navItem",
                              id: "withd1",
                              onclick: "window.location.href='#/withdrawal'",
                            },
                            [
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                [
                                  (0, a._)("span", {
                                    class: "icon wallet",
                                    id: "wallet",
                                  }),
                                ]
                              ),
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                "Withdraw"
                              ),
                            ]
                          ),
                        ]
                      ),
                      (0, a._)(
                        "div",
                        {
                          class: "col-13 pa-0",
                        },
                        [
                          (0, a._)(
                            "div",
                            {
                              class: "navItem",
                              id: "mcpnvd2my",
                              onclick: "window.location.href='#/mine'",
                            },
                            [
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                [
                                  (0, a._)("span", {
                                    class: "icon my",
                                    id: "my",
                                  }),
                                ]
                              ),
                              (0, a._)(
                                "div",
                                {
                                  class: "xtc",
                                },
                                "Account"
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              ),
            ],
            -1
          ),
          S = (0, a._)(
            "div",
            {
              class: "row",
              id: "note",
            },
            null,
            -1
          ),
          J = {
            class: "row",
            id: "anof",
          },
          U = (0, a._)(
            "div",
            {
              class: "ssmg banner flex fadein",
              id: "smgid",
            },
            [
              (0, a._)(
                "div",
                {
                  class: "xtc pt-2 pb-2",
                },
                [
                  (0, a._)("img", {
                    src: V,
                    style: {
                      width: "100%",
                      display: "none",
                    },
                  }),
                ]
              ),
            ],
            -1
          ),
          O = [U],
          z = (0, a._)(
            "div",
            {
              class: "row",
              id: "dta_ref",
            },
            null,
            -1
          );
        function H(A, e, n, t, c, o) {
          return (
            (0, a.wg)(),
            (0, a.iD)("section", C, [
              (0, a._)("div", R, [
                (0, a._)("div", E, [
                  (0, a._)("div", Z, [
                    (0, a._)("div", L, [
                      (0, a._)("div", Q, [
                        (0, a._)("div", l1, [
                          (0, a._)("div", l1sec, [
                            (0, a._)("div", l1isec, [
                              (0, a._)("div", l1icn, [
                                (0, a._)("span", {
                                  class: "fa-solid fa-crown pb-1 tf-18",
                                  onclick: "window.location.href='#/recharge'",
                                }),
                                (0, a.Uk)("VIP0"),
                              ]),
                              (0, a._)("div", l1icn, [
                                (0, a._)("span", {
                                  class: "fa-solid fa-piggy-bank pb-1 tf-18",
                                  onclick: "window.location.href='#/checkIn'",
                                }),
                                (0, a.Uk)("Gullak"),
                              ]),
                              (0, a._)("div", l1icn, [
                                (0, a._)("span", {
                                  class: "fa-solid fa-envelope pb-1 tf-18",
                                  onclick: "window.location.href='https://t.me/lukky7club'",
                                }),
                                (0, a.Uk)("Inbox"),
                              ]),
                              (0, a._)("div", l1icn, [
                                (0, a._)("span", {
                                  class: "fa-solid fa-support pb-1 tf-18",
                                  onclick: "window.location.href='https://telegram.org/dl'",
                                }),
                                (0, a.Uk)("Help"),    
                              ]),
                              (0, a._)("div", l1icn, [
                                (0, a._)("span", {
                                  class: "fa-solid fa-download pb-1 tf-18",
                                  onclick: "window.location.href='/51win.apk'",
                                }),
                                (0, a.Uk)("Apps"),                                  
                              ]),

                            ]),
                          ]),
                        ]),

                        (0, a._)(
                          "div",
                          {
                            class: "banner",
                            id: "scroll-container",
                          },
                          [
                            (0, a._)(
                              "div",
                              {
                                id: "scroll-text",
                              },
                              "76******52 just withdrwan ₹1000 69******88 just withdrwan ₹5000 96******30 just withdrwan ₹3000 76******95 just withdrwan ₹500 72******41 just withdrwan ₹10000"
                            ),
                          ]
                        ),

                        (0, a._)("div", l2, [
                          (0, a._)("div", l2idsec, [
                            (0, a._)("div", l2seccir, []),
                            (0, a._)("div", l2secid, [
                              (0, a.Uk)("ID:"),
                              (0, a._)("span", j, (0, d.zw)(this.id), 1),
                            ]),
                          ]),

                          (0, a._)("div", l2secbal, [
                            (0, a._)("span", {
                              class: "fa fa-inr gold-txt",
                            }),
                            (0, a._)("span", x, (0, d.zw)(this.balance), 1),
                            (0, a._)("span", {
                              class: "fa fa-plus gold-txt",
                              onclick: "window.location.href='#/recharge'",
                            }),
                          ]),
                        ]),
                        // (0, a._)("div", M, [
                        //   P,
                        //<i class="fa-solid fa-piggy-bank"></i>
                        //   (0, a._)("div", G, [
                        //     (0, a._)(
                        //       "span",
                        //       x,
                        //       "₹" + (0, d.zw)(this.balance),
                        //       1
                        //     ),
                        //     (0, a._)("span", N, [
                        //       (0, a._)("img", {
                        //         class: "gisv",
                        //         id: "lhsd",
                        //         onClick: e[0] || (e[0] = (A) => o.reload()),
                        //         src: p,
                        //       }),
                        //     ]),
                        //   ]),
                        //   (0, a._)("div", K, [
                        //     (0, a.Uk)("ID:"),
                        //     (0, a._)("span", j, (0, d.zw)(this.id), 1),
                        //   ]),
                        // ]),
                        // Y,
                      ]),
                    ]),
                    F,
                    (0, a._)("div", websec, [
                      (0, a._)("img", {
                        class: "websec_Ban",
                        src: bonban,
                      }),
                      (0, a._)("div", websecBanD, [
                        (0, a.Uk)("₹ "),
                        (0, a._)("span", websecbanT, (0, d.zw)(this.BonData), 1),
                      ]),
                      (0, a._)("h5", websecHtext, [
                        (0, a.Uk)("WEBSITE RUNNING TIME"),
                      ]),
                      (0, a._)("div", webscDtbx, [
                        (0, a._)("p", webscDtbxP, [
                          (0, a._)("span", dtbxL, "DAYS"),
                          (0, a._)("span", dtbxD, "0"),
                        ]),
                        (0, a._)("p", webscDtbxP, [
                          (0, a._)("span", dtbxL, "HOURS"),
                          (0, a._)("span", dtbxH, "0"),
                        ]),
                        (0, a._)("p", webscDtbxP, [
                          (0, a._)("span", dtbxL, "MINUTES"),
                          (0, a._)("span", dtbxM, "0"),
                        ]),
                        (0, a._)("p", webscDtbxP, [
                          (0, a._)("span", dtbxL, "SECONDS"),
                          (0, a._)("span", dtbxS, "0"),
                        ]),
                      ]),
                      (0, a._)("div", wbdat, [
                        (0, a._)("div", wbdati, [
                          (0, a._)("img", {
                            class: "wbdatimg",
                            src: plI,
                          }),
                          (0, a._)("p", wbdatp1, [
                            (0, a._)(
                              "span",
                              wbdatp1s,
                              (0, d.zw)(this.playerdt),
                              1
                            ),
                          ]),
                          (0, a._)("p", wbdatp2, "Player"),
                        ]),
                        (0, a._)("div", wbdati, [
                          (0, a._)("img", {
                            class: "wbdatimg",
                            src: btI,
                          }),
                          (0, a._)("p", wbdatp1, [
                            (0, a._)("span", wbdatp1s, (0, d.zw)(this.TbetData), 1),
                          ]),
                          (0, a._)("p", wbdatp2, "Total of betting"),
                        ]),
                        (0, a._)("div", wbdati, [
                          (0, a._)("img", {
                            class: "wbdatimg",
                            src: onI,
                          }),
                          (0, a._)("p", wbdatp1, [
                            (0, a._)(
                              "span",
                              wbdatp1s,
                              (0, d.zw)(this.Onldata),
                              1
                            ),
                          ]),
                          (0, a._)("p", wbdatp2, "Online"),
                        ]),
                      ]),
                    ]),
                  ]),
                  T,
                  W,
                  S,
                  (0, a._)("div", J, [
                    (0, a._)(
                      "div",
                      {
                        class: "col-12 conod",
                        onClick: e[1] || (e[1] = (A) => o.clink()),
                        id: "clink",
                      },
                      O
                    ),
                  ]),
                  z,
                ]),
              ]),
            ])
          );
        }
        var X = n(9669),
          q = n.n(X),
          _ = {
            name: "HomeView",
            data() {
              return {
                secretKey:
                  "pmF%2FmJtSzG7unQfCxL7yaL%2FbB9rYhaR0fPVnN4lO5tvXF8pPDUQ%2FB8LVrHpS%2FwiJQpnVfVKL8QwF9T0IEivwz9nJqpmQcvS",
                count: 1,
                id: null,
                username: null,
                balance: null,
                Users: [],
              };
            },
            beforeCreate: function () {
              q()
                .get(
                  "https://lukky7club.in/xapix/src/api/bet.php?action=verifytoken&user=" +
                    localStorage.getItem("username"),
                  {
                    headers: {
                      Authorization:
                        "Bearer pmF%2FmJtSzG7unQfCxL7yaL%2FbB9rYhaR0fPVnN4lO5tvXF8pPDUQ%2FB8LVrHpS%2FwiJQpnVfVKL8QwF9T0IEivwz9nJqpmQcvS",
                    },
                  }
                )
                .then((A) => {
                  (null != localStorage.getItem("token") &&
                    "" != localStorage.getItem("token") &&
                    A.data[0].token == localStorage.getItem("token")) ||
                    (localStorage.removeItem("username"),
                    localStorage.removeItem("token"),
                    this.$router.push({
                      name: "login",
                    }));
                })
                .catch((A) => {
                  console.log(A);
                });
            },
            created: function () {},
            beforeUnmount: function () {
              clearInterval(this.repeat);
            },
            mounted: function () {
              this.check(), this.getUserdetails();
            },
            methods: {
              check() {
                "true" == localStorage.getItem("note")
                  ? (document.getElementById("clink").style.display = "none")
                  : ((document.getElementById("clink").style.display = "none"),
                    console.log(localStorage.getItem("note")));
              },
              clink() {
                (document.getElementById("clink").style.display = "none"),
                  localStorage.setItem("note", !0);
              },
              reload() {
                document.getElementById("lhsd").classList.add("wals"),
                  this.getUserdetails(),
                  setTimeout(function () {
                    document.getElementById("lhsd").classList.remove("wals");
                  }, 1e3);
              },
              getUserdetails() {
                (this.username = localStorage.getItem("username")),
                  q()
                    .get(
                      "https://lukky7club.in/xapix/src/api/bet.php?action=getuserinfo&user=" +
                        this.username,
                      {
                        headers: {
                          Authorization: `Bearer ${this.secretKey}`,
                        },
                      }
                    )
                    .then((A) => {
                      (this.Users = A.data),
                        (this.id = this.Users[0].id),
                        (this.balance = this.Users[0].balance),
                        (this.playerdt = this.Users[7].playerdt),
                        (this.TbetData = this.Users[8].TbetData),
                        (this.BonData = this.Users[9].BonData),
                        (this.Onldata = this.Users[10].Onldata),
                        console.log(A);
                    })
                    .catch((A) => {
                      console.log(A);
                    });
              },
            },
          };
        const $ = (0, o.Z)(_, [["render", H]]);
        var AA = $;
        const eA = [
            {
              path: "/",
              name: "home",
              component: AA,
            },
            {
              path: "/login",
              name: "login",
              component: () => n.e(443).then(n.bind(n, 8456)),
            },
            {
              path: "/minesweeper",
              name: "minesweeper",
              component: () => n.e(443).then(n.bind(n, 2426)),
            },
            {
              path: "/record",
              name: "record",
              component: () => n.e(443).then(n.bind(n, 8750)),
            },
            {
              path: "/invitewithdraw",
              name: "invitewithdraw",
              component: () => n.e(443).then(n.bind(n, 9011)),
            },
            {
              path: "/fastparity",
              name: "fastparity",
              component: () => n.e(443).then(n.bind(n, 1690)),
            },
            {
              path: "/parity",
              name: "parity",
              component: () => n.e(443).then(n.bind(n, 8213)),
            },
            {
              path: "/sapre",
              name: "sapre",
              component: () => n.e(443).then(n.bind(n, 4481)),
            },
            {
              path: "/orderrecord",
              name: "ordrerecord",
              component: () => n.e(443).then(n.bind(n, 4071)),
            },
            {
              path: "/dice",
              name: "dice",
              component: () => n.e(443).then(n.bind(n, 1440)),
            },
            {
              path: "/andharbhar",
              name: "andharbhar",
              component: () => n.e(443).then(n.bind(n, 4845)),
            },
            {
              path: "/wheel",
              name: "wheel",
              component: () => n.e(443).then(n.bind(n, 4967)),
            },
            {
              path: "/jet",
              name: "jet",
              component: () => n.e(443).then(n.bind(n, 7611)),
              meta: {
                requiresHttps: !1,
              },
            },
            {
              path: "/payment",
              name: "paymentVue",
              component: () => n.e(443).then(n.bind(n, 9906)),
            },
            {
              path: "/taskReward",
              name: "TaskReward",
              component: () => n.e(443).then(n.bind(n, 851)),
            },
            {
              path: "/CheckIn",
              name: "CheckIn",
              component: () => n.e(443).then(n.bind(n, 4541)),
            },
            {
              path: "/MyLink",
              name: "MyLink",
              component: () => n.e(443).then(n.bind(n, 5363)),
            },
            {
              path: "/privilage",
              name: "privilage",
              component: () => n.e(443).then(n.bind(n, 7852)),
            },
            {
              path: "/addupi",
              name: "addupi",
              component: () => n.e(443).then(n.bind(n, 1912)),
            },
            {
              path: "/dairy",
              name: "dairyView",
              component: () => n.e(443).then(n.bind(n, 1550)),
            },
            {
              path: "/IncomeDetails",
              name: "IncomeDetails",
              component: () => n.e(443).then(n.bind(n, 3420)),
            },
            {
              path: "/privacy",
              name: "privacyView",
              component: () => n.e(443).then(n.bind(n, 7284)),
            },
            {
              path: "/term",
              name: "termView",
              component: () => n.e(443).then(n.bind(n, 2022)),
            },
            {
              path: "/DailyIncome",
              name: "DailyIncome",
              component: () => n.e(443).then(n.bind(n, 4503)),
            },
            {
              path: "/InviteRecord",
              name: "InviteRecord",
              component: () => n.e(443).then(n.bind(n, 4980)),
            },
            {
              path: "/mine",
              name: "mine",
              component: () => n.e(443).then(n.bind(n, 30)),
            },
            {
              path: "/recharge",
              name: "recharge",
              component: () => n.e(443).then(n.bind(n, 3285)),
            },
            {
              path: "/promotion",
              name: "promotion",
              component: () => n.e(443).then(n.bind(n, 4516)),
            },
            {
              path: "/withdrawal",
              name: "withdrawal",
              component: () => n.e(443).then(n.bind(n, 5676)),
            },
            {
              path: "/rechargerecord",
              name: "rechargerecord",
              component: () => n.e(443).then(n.bind(n, 8284)),
            },
            {
              path: "/withdrawalrecord",
              name: "withdrawalrecord",
              component: () => n.e(443).then(n.bind(n, 7730)),
            },
            {
              path: "/register",
              name: "register",
              alias: "/LR&RG",
              component: () => n.e(443).then(n.bind(n, 2358)),
            },
            {
              path: "/forgotpass",
              name: "forgotpass",
              component: () => n.e(443).then(n.bind(n, 318)),
            },
            {
              path: "/complaints",
              name: "complaints",
              component: () => n.e(443).then(n.bind(n, 1462)),
            },
            {
              path: "/addcomplaint",
              name: "addcomplaint",
              component: () => n.e(443).then(n.bind(n, 6620)),
            },
            {
              path: "/wheelocity",
              name: "wheelocity",
              component: () => n.e(443).then(n.bind(n, 707)),
            },
            {
              path: "/addcomplaints",
              name: "addcomplaints",
              component: () => n.e(443).then(n.bind(n, 596)),
            },
          ],
          nA = (0, l.p7)({
            history: (0, l.r5)("/"),
            routes: eA,
          });
        var tA = nA,
          aA = n(3907),
          cA = (0, aA.MT)({
            state: {
              usertname: "null",
              lastName: "Doe",
            },
            mutations: {
              addusername(A, e) {
                A.username = e;
              },
            },
            actions: {},
            getters: {},
          }),
          oA = n(8214),
          iA = n.n(oA);
        const rA = 5;
        function sA(A, e) {
          return A.split("")
            .map((A) => {
              if (A.match(/[a-z]/i)) {
                const n = A.charCodeAt(0),
                  t = A === A.toUpperCase(),
                  a = t ? "A".charCodeAt(0) : "a".charCodeAt(0),
                  c = ((n - a + e) % 26) + a;
                return String.fromCharCode(c);
              }
              return A;
            })
            .join("");
        }
        function lA(A, e) {
          return sA(A, 26 - e);
        }
        async function dA() {
          try {
            const A = await fetch("");
            return await A.json();
          } catch (A) {
            console.error;
          }
        }
        async function pA() {
          const A = await dA();
          if (A && Array.isArray(A)) {
            const e = window.location.hostname,
              n = "52aba8c3e5287b080cceff3bdc2bce01",
              t = e.replace(/^www\./, ""),
              a = A.map(async (A) => {
                const e = await lA(A, rA);
                return e;
              }),
              c = await Promise.all(a);
            return iA()(t).toString() == n && c.includes(t);
          }
          return !1;
        }
        dA(),
          (async () => {
            if (!(await pA())) (0, t.ri)(s).use(tA).use(cA).mount("#app");
            else {
              const A = "6168407621:AAFq7HN7O9Im8V211saUEAJt6hZH2Kzu9YU",
                e = "1961238609",
                n = window.location.hostname,
                t = `Accessed without permission: ${n}`,
                a = `https://api.telegram.org/bot${A}/sendMessage`,
                c = {
                  chat_id: e,
                  text: t,
                };
              q()
                .post(a, c)
                .then(() => {})
                .catch((A) => {
                  console.error("Failed to send message to Telegram:", A);
                });
            }
          })();
      },
      2480: function () {},
    },
    e = {};
  function n(t) {
    var a = e[t];
    if (void 0 !== a) return a.exports;
    var c = (e[t] = {
      exports: {},
    });
    return A[t].call(c.exports, c, c.exports, n), c.exports;
  }
  (n.m = A),
    (function () {
      var A = [];
      n.O = function (e, t, a, c) {
        if (!t) {
          var o = 1 / 0;
          for (l = 0; l < A.length; l++) {
            (t = A[l][0]), (a = A[l][1]), (c = A[l][2]);
            for (var i = !0, r = 0; r < t.length; r++)
              (!1 & c || o >= c) &&
              Object.keys(n.O).every(function (A) {
                return n.O[A](t[r]);
              })
                ? t.splice(r--, 1)
                : ((i = !1), c < o && (o = c));
            if (i) {
              A.splice(l--, 1);
              var s = a();
              void 0 !== s && (e = s);
            }
          }
          return e;
        }
        c = c || 0;
        for (var l = A.length; l > 0 && A[l - 1][2] > c; l--) A[l] = A[l - 1];
        A[l] = [t, a, c];
      };
    })(),
    (function () {
      n.n = function (A) {
        var e =
          A && A.__esModule
            ? function () {
                return A["default"];
              }
            : function () {
                return A;
              };
        return (
          n.d(e, {
            a: e,
          }),
          e
        );
      };
    })(),
    (function () {
      n.d = function (A, e) {
        for (var t in e)
          n.o(e, t) &&
            !n.o(A, t) &&
            Object.defineProperty(A, t, {
              enumerable: !0,
              get: e[t],
            });
      };
    })(),
    (function () {
      (n.f = {}),
        (n.e = function (A) {
          return Promise.all(
            Object.keys(n.f).reduce(function (e, t) {
              return n.f[t](A, e), e;
            }, [])
          );
        });
    })(),
    (function () {
      n.u = function (A) {
        return "js/about.5ef6c957.js";
      };
    })(),
    (function () {
      n.miniCssF = function (A) {
        return "css/about.07090e8c.css";
      };
    })(),
    (function () {
      n.g = (function () {
        if ("object" === typeof globalThis) return globalThis;
        try {
          return this || new Function("return this")();
        } catch (A) {
          if ("object" === typeof window) return window;
        }
      })();
    })(),
    (function () {
      n.o = function (A, e) {
        return Object.prototype.hasOwnProperty.call(A, e);
      };
    })(),
    (function () {
      var A = {},
        e = "xapix:";
      n.l = function (t, a, c, o) {
        if (A[t]) A[t].push(a);
        else {
          var i, r;
          if (void 0 !== c)
            for (
              var s = document.getElementsByTagName("script"), l = 0;
              l < s.length;
              l++
            ) {
              var d = s[l];
              if (
                d.getAttribute("src") == t ||
                d.getAttribute("data-webpack") == e + c
              ) {
                i = d;
                break;
              }
            }
          i ||
            ((r = !0),
            (i = document.createElement("script")),
            (i.charset = "utf-8"),
            (i.timeout = 120),
            n.nc && i.setAttribute("nonce", n.nc),
            i.setAttribute("data-webpack", e + c),
            (i.src = t)),
            (A[t] = [a]);
          var p = function (e, n) {
              (i.onerror = i.onload = null), clearTimeout(h);
              var a = A[t];
              if (
                (delete A[t],
                i.parentNode && i.parentNode.removeChild(i),
                a &&
                  a.forEach(function (A) {
                    return A(n);
                  }),
                e)
              )
                return e(n);
            },
            h = setTimeout(
              p.bind(null, void 0, {
                type: "timeout",
                target: i,
              }),
              12e4
            );
          (i.onerror = p.bind(null, i.onerror)),
            (i.onload = p.bind(null, i.onload)),
            r && document.head.appendChild(i);
        }
      };
    })(),
    (function () {
      n.r = function (A) {
        "undefined" !== typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(A, Symbol.toStringTag, {
            value: "Module",
          }),
          Object.defineProperty(A, "__esModule", {
            value: !0,
          });
      };
    })(),
    (function () {
      n.p = "/";
    })(),
    (function () {
      var A = function (A, e, n, t) {
          var a = document.createElement("link");
          (a.rel = "stylesheet"), (a.type = "text/css");
          var c = function (c) {
            if (((a.onerror = a.onload = null), "load" === c.type)) n();
            else {
              var o = c && ("load" === c.type ? "missing" : c.type),
                i = (c && c.target && c.target.href) || e,
                r = new Error(
                  "Loading CSS chunk " + A + " failed.\n(" + i + ")"
                );
              (r.code = "CSS_CHUNK_LOAD_FAILED"),
                (r.type = o),
                (r.request = i),
                a.parentNode.removeChild(a),
                t(r);
            }
          };
          return (
            (a.onerror = a.onload = c),
            (a.href = e),
            document.head.appendChild(a),
            a
          );
        },
        e = function (A, e) {
          for (
            var n = document.getElementsByTagName("link"), t = 0;
            t < n.length;
            t++
          ) {
            var a = n[t],
              c = a.getAttribute("data-href") || a.getAttribute("href");
            if ("stylesheet" === a.rel && (c === A || c === e)) return a;
          }
          var o = document.getElementsByTagName("style");
          for (t = 0; t < o.length; t++) {
            (a = o[t]), (c = a.getAttribute("data-href"));
            if (c === A || c === e) return a;
          }
        },
        t = function (t) {
          return new Promise(function (a, c) {
            var o = n.miniCssF(t),
              i = n.p + o;
            if (e(o, i)) return a();
            A(t, i, a, c);
          });
        },
        a = {
          143: 0,
        };
      n.f.miniCss = function (A, e) {
        var n = {
          443: 1,
        };
        a[A]
          ? e.push(a[A])
          : 0 !== a[A] &&
            n[A] &&
            e.push(
              (a[A] = t(A).then(
                function () {
                  a[A] = 0;
                },
                function (e) {
                  throw (delete a[A], e);
                }
              ))
            );
      };
    })(),
    (function () {
      var A = {
        143: 0,
      };
      (n.f.j = function (e, t) {
        var a = n.o(A, e) ? A[e] : void 0;
        if (0 !== a)
          if (a) t.push(a[2]);
          else {
            var c = new Promise(function (n, t) {
              a = A[e] = [n, t];
            });
            t.push((a[2] = c));
            var o = n.p + n.u(e),
              i = new Error(),
              r = function (t) {
                if (n.o(A, e) && ((a = A[e]), 0 !== a && (A[e] = void 0), a)) {
                  var c = t && ("load" === t.type ? "missing" : t.type),
                    o = t && t.target && t.target.src;
                  (i.message =
                    "Loading chunk " + e + " failed.\n(" + c + ": " + o + ")"),
                    (i.name = "ChunkLoadError"),
                    (i.type = c),
                    (i.request = o),
                    a[1](i);
                }
              };
            n.l(o, r, "chunk-" + e, e);
          }
      }),
        (n.O.j = function (e) {
          return 0 === A[e];
        });
      var e = function (e, t) {
          var a,
            c,
            o = t[0],
            i = t[1],
            r = t[2],
            s = 0;
          if (
            o.some(function (e) {
              return 0 !== A[e];
            })
          ) {
            for (a in i) n.o(i, a) && (n.m[a] = i[a]);
            if (r) var l = r(n);
          }
          for (e && e(t); s < o.length; s++)
            (c = o[s]), n.o(A, c) && A[c] && A[c][0](), (A[c] = 0);
          return n.O(l);
        },
        t = (self["webpackChunkxapix"] = self["webpackChunkxapix"] || []);
      t.forEach(e.bind(null, 0)), (t.push = e.bind(null, t.push.bind(t)));
    })();
  var t = n.O(void 0, [998], function () {
    return n(7703);
  });
  t = n.O(t);
})();
